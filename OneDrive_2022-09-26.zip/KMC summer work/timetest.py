import numpy as np
import nice
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

MAX=4000
i=1000
x=[]
y=[]
concs = np.array([1.0,10,0.0001,0.0,0.0,0.0]) #A,D,R,AD,DR,ADR try D=10 to correspond with the 2nd peak on fig 19
keqs = np.array([1.0e6,100,1.0,100]) # A+D, D+R, A+DR, AD+R
stoich = np.array([[-1,-1, 0, 1, 0, 0],
		   [ 0,-1,-1, 0, 1, 0],
		   [ 0, 0,-1,-1, 0, 1],
		   [-1, 0, 0, 0,-1, 1]])
while i<MAX:
	solver = nice.NEKMCSolver(concs,stoich,keq_values=keqs)
	solver.run(mode='dynamic',step=1e-8,maxiter=i,inner=1000,tol_s=1.0e-10)
	exact = nice.ExactSolver(concs, stoich, keq_values=keqs)
	exact.run(guess=solver.compute_zeta(),tol=1.0e-10)
	x.append(i)
	y.append(solver.concs[5])
	i+=1000

plt.plot(x,y)
plt.xlabel('Number of Iterations')
plt.ylabel('[ADR]')
plt.title('Relationship Between [ADR] and the Number of Iterations' + '\n' + '[A] =' + str(concs[0]) + '\n' + '[R] =' + str(concs[2]))
#plt.show()
plt.savefig("mygraph.png")

#with open("[ADR]_iterations.txt", 'r') as f:
#	f.write(y)
# so I'm trying to figure out whether there's a way to have a function of y and x
# x is the number of iteration - 1000 to 1e8 every 1000 iterations so like range([1000,1e8,1000])
# y is [ADR] 
# seeing if I can run the code but record [ADR] every inner # of iterations
# keep the maxiter at 1e8 (or even higher) and not change it
# so I was doing this wrong... iterations and time are not the same thing
