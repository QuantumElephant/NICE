import numpy as np
import nice
from nice import NEKMCSolver, KMCSolver
import matplotlib.pyplot as plt
import csv
import math
import time

start_time = time.time()

n=10 # n goes up to Ncancer
m=5 # m goes up to Nimmune
Ncan = 10
Nimm = 5
Kcan = 10**-1
Kimm = 10**-3
#BOTH K VALUES MIGHT BE HIGHER BY A FACTOR OF 10-100
#k = [0,1,2,3,4,5]
b = 1 # Try 0.1, 1, 10
b_1 = b
a= 1 # Try 0.1, 1, 10 
a_1=a
tau = 0.5

keqs = [0 for i in range(2*m+2*n+(m*n))]
concs = [0 for i in range(2*m+2*n+4)]
stoich = np.zeros(shape=(len(keqs),len(concs)),dtype='int') 
#concs[2*m+2*n] = 10**k[0] # AB do a for loop to index k
concs[2*m+2*n+1] = 10/Ncan # C
concs[2*m+2*n+2] = 100/Nimm # D

stoich[0,2*m+2*n+2] = -1 #D
stoich[0,2*m+2*n] = -1 #AB
stoich[0,0] = 1 #ABD
stoich[m,2*m+2*n] = -1 #AB
stoich[m,2*m+2*n+1] = -1 #C
stoich[m,m] = 1 #CAB

for i in range(1,m):
	stoich[i,2*m+2*n] = -1 # AB
	stoich[i,i-1] = -1 # ABmD
	stoich[i,i] = 1 # Am+1D
	# AB + ABnD -> ABm+1D

for i in range(m+1,m+n):
	stoich[i, 2*m+2*n] = -1 #AB
	stoich[i,i-1] = -1 #CABn
	stoich[i,i] = 1 #CABn+1
	#CABn + AB -> CABn+1

for i in range(0, m):
	stoich[m+n+i,i] = -1 # ABmD
	for j in range(1,n):
		stoich[m+n+i+(m*j),i] = -1 
for i in range(0,n):
	stoich[m+n+(i*m),m+i] = -1 #CABn
	for j in range(1,m):
		stoich[m+n+(i*m)+j,m+i] = -1
for i in range(0,m):
	stoich[m+n+i,m+n+i+1] = 1 # CABm+nD
	for j in range(1,n):
		stoich[m+n+i+(m*j),m+n+i+j+1] = 1 
for i in range(0,m+n):
	stoich[m+n+(m*n)+i,2*m+2*n+3] = 1 # death 
	stoich[m+n+(m*n)+i,m+n+i] = -1 #CABm+nD
	keqs[m+n+(m*n)+i] = 10000 # CADm+nD -> death


for i in range(0,m):
	keqs[i] = (Nimm-i)*Kimm*b**(i/Nimm)
for i in range(0,n):
	keqs[m+i] = (Ncan-i)*Kcan*a**(i/Ncan)

def nCr(n,k):
	return math.factorial(n)/(math.factorial(k)*math.factorial(n-k))
def immsum(m,n):
	Imm=[]
	for i in range(1,(min(Nimm-m,n))+1):
		Imm.append(math.factorial(i)*nCr(Nimm-m,i)*nCr(n,i)*b_1**((m+i-1)/Nimm))
	if n == m ==1:
		return(math.factorial(1)*nCr(Nimm-m,1)*nCr(n,1)*b_1**((m+1-1)/Nimm))		
	return sum(Imm)

def cansum(m,n):
	Can = []
	for i in range(1,(min(Ncan-n,m))+1):
		Can.append(math.factorial(i)*nCr(Ncan-n,i)*nCr(m,i)*a_1**((n+i-1)/Ncan))
	if n == m == 1:
		return(math.factorial(1)*nCr(Ncan-n,1)*nCr(m,1)*a_1**((n+1-1)/Ncan))
	return sum(Can)


for i in range(1,m+1): 
	for j in range(1,n+1):
		keqs[j*m+n+(i-1)] = (1-(i/Nimm)*(j/Ncan))**(tau*min(Ncan,Nimm))*(Kimm*immsum(i,j)+Kcan*cansum(i,j))


x=[]
y=[]
with open('revisedmodelvalues.txt','a') as text:
    #text.write('Nimm = ' + str(Nimm) + ' | ' +'Kimm = ' + str(Kimm) + ' | ' +  'n = ' + str(n) + ' | ' + 'm = ' + str(m) + ' | ' + 'Ncan = ' + str(Ncan) + ' | ' + 'Kcan = ' + str(Kcan) + ' | ' + 'a = ' + str(a) + ' | ' + 'a_1 = ' + str(a_1) + ' | ' + 'b = ' + str(b) + '|' + 'b_1 = ' + str(b_1) + ' | ' + 'tau = ' + str(tau))
    concs[2*m+2*n] = 10**(3.75)
    solver = nice.NEKMCSolver(concs,stoich,keq_values=keqs)
    solver.run_simulation(mode = 'dynamic',step=1e-6,niter=5000000)
    exact=nice.ExactSolver(concs,stoich,keq_values=keqs)
    exact.optimize(guess=solver.compute_zeta(),tol=1e-10)
    #x.append(math.log10(concs[2*m+2*n]))
    #y.append(solver.concs[2*m+2*n+3])
    text.write(str(solver.concs[2*m+2*n+3]) + '10^3.75' + '\n')
print(solver.concs[2*m+2*n+3])
#plt.plot(x,y)
#plt.xlabel('log_10([AB])')
#plt.ylabel('Concentration of Dead Cells in nM')
#plt.title('How the Concentration of Dead Cells Vary' +'\n' + 'With the Initial Concentration of AB' + '\n' + 'n = ' + str(n) + ' m =' + str(m))
#plt.savefig('AB vs Death2')

#print(str(keqs) + '\n' + str(stoich) + '\n' +  str(concs))
#print(solver.concs[2*m+2*n+3])

e = int(time.time() - start_time)
print('{:02d}:{:02d}:{:02d}'.format(e//3600, (e % 3600 // 60), e % 60))
"""
AB + D -> ABD K = Nimm*Kimm
AB + ABD -> (AB)2D K = (Nimm-1)*Kimm*b**1/Nimm
...
AB+ABmD ->ABm+1D K = (Nimm-m)*Kimm*b**m/Nimm

C + AB -> CAB K = Ncan*Kcan
CAB + AB -> CAB2 K = (Ncan-1)*Kcan*a**1/Ncan
...
CABnAB -> CABn+1 K = (Ncan - n)*Kcan*a**n/Ncan TRY VARYING A FROM 0.1,1,10 ETC

ABD + CAB -> CAB2D
ABD + CAB2 -> CAB3D
...
ABD+CABn -> CABn+1D
AB2D+CAB -> CAB3D
...
AB2D + CABn -> CABn+2D
...
ABmD + CABn -> CABn+mD K value on the documnet, long and complicated 

ABm+nD -> Death

ABD, AB2D,...,ABmD, CAB,CAB2,...CABn, CABD, CAB2D,...,CABn+mD, AB,C,D, death
ABD -> ABmD = 0 - m-1
CAB -> CABn = m - m+n-1
CABD -> CABm+nD -> m+n ->2m+2n-1
AB = 2m+2n
C = 2m+2n+1
D = 2m+2n+2
"""