import numpy as np
import nice
import matplotlib.pyplot as plt

x=[]
y=[]
concs = np.array([1.0,10,0.0001,0.0,0.0,0.0]) #A,D,R,AD,DR,ADR try D=10 to correspond with the 2nd peak
keqs = np.array([1.0,100,1.0,100]) # A+D, D+R, A+DR, AD+R
stoich = np.array([[-1,-1, 0, 1, 0, 0],
		   [ 0,-1,-1, 0, 1, 0],
		   [ 0, 0,-1,-1, 0, 1],
		   [-1, 0, 0, 0,-1, 1]])
for i in np.arange(0,1,0.01):
	nekmc = nice.NEKMCSolver(concs,stoich,keq_values=keqs)
	time = nekmc.run(mode='dynamic',step=1e-8,maxiter=5e8,inner=100,tol_t=i)
	exact = nice.ExactSolver(concs, stoich, keq_values=keqs)
	exact.run(guess=nekmc.compute_zeta(),tol=1.0e-10)
	x.append(time[0])
	y.append(nekmc.concs[5])
	with open("times.txt","w") as f:
		f.write(str(y))
			
#print(time[0])
#print(nekmc.concs)
#print(exact.concs)
#	x.append(nekmc.run(mode='dynamic',step=1e-8,maxiter=1e8,inner=1000,tol_s=1.0e-10,tol_t=1.0e12)[0])
#	y.append(exact.concs[5])
#	i+=1
#print(nekmc.run(mode='dynamic',step=1e-8,maxiter=1e8,inner=1000,tol_s=1.0e-10,tol_t=1.0e12)[0])

plt.plot(x,y,'ro')
plt.xlabel('Time')
plt.ylabel('[ADR]')
plt.title('Time Curve for [ADR]' + '\n' '[A] =' + str(concs[0]) + '\n' + '[R] =' + str(concs[2]))
plt.show()

