import numpy as np
import nice
from nice.nekmc import NEKMCSolver
from nice.nekmc import KMCSolver
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import csv
import os.path
from mpl_toolkits import mplot3d

# MAX N=2 MODEL
keqs = np.array([10, 20, 10, 20]) #AB+D, AB+ABD, ABC+D,AB2D+C
stoich = np.array([[-1, -1,  0,  1,  0,  0,  0,  0],
                   [-1,  0,  0, -1,  0,  1,  0,  0],
                   [ 0, -1, -1,  0,  1,  0,  0,  0],
                   [ 0, -1,  0,  0,  0,  0,  1, -1]])
#concs = np.array([AB[i], 1.0, ABC[j], 0.0, 0.0, 0.0, 0.0, (0.5**1)*ABC[j]])
#ans = ((solver.concs[4] + solver.concs[6])/(ABC[j] + (0.5**1)*ABC[j]))

AB = [] # first went from 0.1 to 102.4
for i in range(51):
	AB.append(0.0001*(1.25**i))

x=[]
y_1=[]
y_2=[]
y_3=[]
y_4=[]

with open('newmodeln2.txt','w') as text:
	for i in range(0,len(AB)):
		concs = np.array([AB[i], 1.0, 0.05, 0.0, 0.0, 0.0, 0.0, (0.5**1)*0.05])
		solver = nice.NEKMCSolver(concs,stoich,keq_values=keqs)
		solver.run_simulation(mode = 'dynamic',step=1e-8,niter=5e8, maxcall=1000)
		exact = nice.ExactSolver(concs,stoich,keq_values=keqs)
		exact.optimize(guess=solver.compute_zeta(),tol=1.0e-10)
		ans = ((solver.concs[4] + solver.concs[6])/(0.05 + (0.5**1)*0.05))
		text.write(str(ans) + ' | ' + '[AB] = ' + str(AB[i]) + '\n')
		y_1.append(ans)
	for i in range(0,len(AB)):
		concs = np.array([AB[i], 1.0, 0.1, 0.0, 0.0, 0.0, 0.0, (0.5**1)*0.1])
		solver = nice.NEKMCSolver(concs,stoich,keq_values=keqs)
		solver.run_simulation(mode = 'dynamic',step=1e-8,niter=5e8, maxcall=1000)
		exact = nice.ExactSolver(concs,stoich,keq_values=keqs)
		exact.optimize(guess=solver.compute_zeta(),tol=1.0e-10)
		ans = ((solver.concs[4] + solver.concs[6])/(0.1 + (0.5**1)*0.1))
		text.write(str(ans) + ' | ' + '[AB] = ' + str(AB[i]) + '\n')
		x.append(np.log10(AB[i]))
		y_2.append(ans)
		i=+1
	for i in range(0,len(AB)):
		concs = np.array([AB[i], 1.0, 0.2, 0.0, 0.0, 0.0, 0.0, (0.5**1)*0.2])
		solver = nice.NEKMCSolver(concs,stoich,keq_values=keqs)
		solver.run_simulation(mode = 'dynamic',step=1e-8,niter=5e8, maxcall=1000)
		exact = nice.ExactSolver(concs,stoich,keq_values=keqs)
		exact.optimize(guess=solver.compute_zeta(),tol=1.0e-10)
		ans = ((solver.concs[4] + solver.concs[6])/(0.2 + (0.5**1)*0.2))
		text.write(str(ans) + ' | ' + '[AB] = ' + str(AB[i]) + '\n')
		y_3.append(ans)
		i=+1
	for i in range(0,len(AB)):
		concs = np.array([AB[i], 1.0, 0.4, 0.0, 0.0, 0.0, 0.0, (0.5**1)*0.4])
		solver = nice.NEKMCSolver(concs,stoich,leq_values=keqs)
		solver.run_simulation(mode = 'dynamic',step=1e-8,niter=5e8, maxcall=1000)
		exact = nice.ExactSolver(concs,stoich,keq_values=keqs)
		exact.optimize(guess=solver.compute_zeta(),tol=1.0e-10)
		ans = ((solver.concs[4] + solver.concs[6])/(0.4 + (0.5**1)*0.4))
		text.write(str(ans) + ' | ' + '[AB] = ' + str(AB[i]) + '\n')		
		y_4.append(ans)
		i=+1

plt.plot(x,y_1,label='[ABC]=0.05')
plt.plot(x,y_2,label='[ABC]=0.1')
plt.plot(x,y_3,label='[ABC]=0.2')
plt.plot(x,y_4,label='[ABC]=0.4')
plt.xlabel('log_10([AB])')
plt.ylabel('Ratio of Product/Reactant')
plt.title('Relationship Between [AB] and the Ratio' + '\n' + 'of Product/Reactants when n_max=2')
plt.legend()
plt.savefig('AB vs PR n2')