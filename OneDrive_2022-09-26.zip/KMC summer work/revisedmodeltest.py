import numpy as np
import nice
from nice.nekmc import NEKMCSolver
from nice.nekmc import KMCSolver
import matplotlib.pyplot as plt
import csv
import os.path
import math

"""
Test Values:
Constants used:
n=2
m=2
Ncan = 10
Nimm = 5
Kcan = 10e-1
Kimm = 10e-3
a = a_1 = 1
b = b_1 = 1
tau = 0.5
k=0

Equilibrium Constants:
C + AB -> CAB K = 1
CAB + AB -> CAB2 K = 0.9
AB + D -> ABD K = 5e-3
AB + ABD -> AB2D K = 4e-3
CAB + ABD ->CAB2D K = 0.859475734
CAB + AB2D ->CAB3D K = 8.129528029
CAB2 + ABD -> CAB3D K = 0.740443517
CAB2 + AB2D -> CAB4D K = 5.854978254
CABD -> death K = 10000
CAB2D -> death K = 10000
CAB3D -> death K = 10000
CAB4D -> deathK = 10000

Initial Concentrations:
C = 10/Ncan = 1
D = 100/Nimm = 20
AB = 10**k = 1
Everything else = 0

Stoich:
[[ 1, 0, 0, 0, 0, 0, 0, 0,-1, 0,-1, 0],
 [-1, 1, 0, 0, 0, 0, 0, 0,-1, 0, 0, 0],
 [ 0, 0, 1, 0, 0, 0, 0, 0,-1,-1, 0, 0],
 [ 0, 0,-1, 1, 0, 0, 0, 0,-1, 0, 0, 0],
 [-1, 0,-1, 0, 0, 1, 0, 0, 0, 0, 0, 0],
 [ 0,-1,-1, 0, 0, 0, 1, 0, 0, 0, 0, 0],
 [-1, 0, 0,-1, 0, 0, 1, 0, 0, 0, 0, 0],
 [ 0,-1, 0,-1, 0, 0, 0, 1, 0, 0, 0, 0],
 [ 0, 0, 0, 0,-1, 0, 0, 0, 0, 0, 0, 1],
 [ 0, 0, 0, 0, 0,-1, 0, 0, 0, 0, 0, 1],
 [ 0, 0, 0, 0, 0, 0,-1, 0, 0, 0, 0, 1],
 [ 0, 0, 0, 0, 0, 0, 0,-1, 0, 0, 0, 1]]
 """

n=2 # n goes up to Ncancer
m=2 # m goes up to Nimmune
Ncan = 10
Nimm = 5
Kcan = 10**-1
Kimm = 10**-3
#BOTH K VALUES MIGHT BE HIGHER BY A FACTOR OF 10-100
k = [0,1,2,3,4,5]
b = 1 # Try 0.1, 1, 10
b_1 = b
a= 1 # Try 0.1, 1, 10 
a_1=a
tau = 0.5

keqs = [0 for i in range(2*m+2*n+(m*n))]
concs = [0 for i in range(2*m+2*n+4)]
stoich = np.zeros(shape=(len(keqs),len(concs)),dtype='int') 
concs[2*m+2*n] = 10**k[0] # AB do a for loop to index k
concs[2*m+2*n+1] = 10/Ncan # C
concs[2*m+2*n+2] = 100/Nimm # D

stoich[0,2*m+2*n+2] = -1 #D
stoich[0,2*m+2*n] = -1 #AB
stoich[0,0] = 1 #ABD
stoich[m,2*m+2*n] = -1 #AB
stoich[m,2*m+2*n+1] = -1 #C
stoich[m,m] = 1 #CAB

for i in range(1,m):
	stoich[i,2*m+2*n] = -1 # AB
	stoich[i,i-1] = -1 # ABmD
	stoich[i,i] = 1 # Am+1D
	# AB + ABnD -> ABm+1D

for i in range(m+1,m+n):
	stoich[i, 2*m+2*n] = -1 #AB
	stoich[i,i-1] = -1 #CABn
	stoich[i,i] = 1 #CABn+1
	#CABn + AB -> CABn+1

for i in range(0, m):
	stoich[m+n+i,i] = -1 # ABmD
	for j in range(1,n):
		stoich[m+n+i+(m*j),i] = -1 
for i in range(0,n):
	stoich[m+n+(i*m),m+i] = -1 #CABn
	for j in range(1,m):
		stoich[m+n+(i*m)+j,m+i] = -1
for i in range(0,m):
	stoich[m+n+i,m+n+i+1] = 1 # CABm+nD
	for j in range(1,n):
		stoich[m+n+i+(m*j),m+n+i+j+1] = 1 
for i in range(0,m+n):
	stoich[m+n+(m*n)+i,2*m+2*n+3] = 1 # death 
	stoich[m+n+(m*n)+i,m+n+i] = -1 #CABm+nD
	keqs[m+n+(m*n)+i] = 10000 # CADm+nD -> death


for i in range(0,m):
	keqs[i] = (Nimm-i)*Kimm*b**(i/Nimm)
for i in range(0,n):
	keqs[m+i] = (Ncan-i)*Kcan*a**(i/Ncan)

def nCr(n,k):
	return math.factorial(n)/(math.factorial(k)*math.factorial(n-k))
def immsum(m,n):
	Imm=[]
	for i in range(1,(min(Nimm-m,n))+1):
		Imm.append(math.factorial(i)*nCr(Nimm-m,i)*nCr(n,i)*b_1**((m+i-1)/Nimm))
	if n == m ==1:
		return(math.factorial(1)*nCr(Nimm-m,1)*nCr(n,1)*b_1**((m+1-1)/Nimm))		
	return sum(Imm)

def cansum(m,n):
	Can = []
	for i in range(1,(min(Ncan-n,m))+1):
		Can.append(math.factorial(i)*nCr(Ncan-n,i)*nCr(m,i)*a_1**((n+i-1)/Ncan))
	if n == m == 1:
		return(math.factorial(1)*nCr(Ncan-n,1)*nCr(m,1)*a_1**((n+1-1)/Ncan))
	return sum(Can)


for i in range(1,m+1): 
	for j in range(1,n+1):
		keqs[j*m+n+(i-1)] = (1-(i/Nimm)*(j/Ncan))**(tau*min(Ncan,Nimm))*(Kimm*immsum(i,j)+Kcan*cansum(i,j))

#for i in range():
solver = nice.NEKMCSolver(concs,stoich,keq_values=keqs)
solver.iterate(step=1e-8,niter=5e8)
solver.run_simulation(mode = 'dynamic',step=1e-8,niter=5e8)
exact=nice.ExactSolver(concs,stoich,keq_values=keqs)
exact.optimize(guess=solver.compute_zeta(),tol=1e-10)


#print(str(keqs) + '\n' + str(stoich) + '\n' +  str(concs))
print(solver.concs[2*m+2*n+3])
"""
AB + D -> ABD K = Nimm*Kimm
AB + ABD -> (AB)2D K = (Nimm-1)*Kimm*b**1/Nimm
...
AB+ABmD ->ABm+1D K = (Nimm-m)*Kimm*b**m/Nimm

C + AB -> CAB K = Ncan*Kcan
CAB + AB -> CAB2 K = (Ncan-1)*Kcan*a**1/Ncan
...
CABnAB -> CABn+1 K = (Ncan - n)*Kcan*a**n/Ncan TRY VARYING A FROM 0.1,1,10 ETC

ABD + CAB -> CAB2D
ABD + CAB2 -> CAB3D
...
ABD+CABn -> CABn+1D
AB2D+CAB -> CAB3D
...
AB2D + CABn -> CABn+2D
...
ABmD + CABn -> CABn+mD K value on the documnet, long and complicated 

ABm+nD -> Death

ABD, AB2D,...,ABmD, CAB,CAB2,...CABn, CABD, CAB2D,...,CABn+mD, AB,C,D, death
ABD -> ABmD = 0 - m-1
CAB -> CABn = m - m+n-1
CABD -> CABm+nD -> m+n ->2m+2n-1
AB = 2m+2n
C = 2m+2n+1
D = 2m+2n+2
"""





