# binomial distribution attempt
# p(x) = nCx p^x (1-p)^n-x
# looking at the probability of heads/tails on a coin
# so p(heads) = 0.50 therefore p(tails) = 0.50 as well
# let's say we're flipping 100 coins first for simplicity
# now we're doing a general one where a user can input their probabilities and max numbers
from math import factorial as fac
import matplotlib.pyplot as plt
p=float(input("probability of success:"))
n=int(input("total number of trials:"))
def bindis(p,n,x):
	return (fac(n)/(fac(x)*fac(n-x)))*(p**x)*((1-p)**(n-x))
x = [i for i in range(n+1)]
y = []
i=0
for i in x:
	y.append(bindis(p,n,i))
	i+=1

plt.plot(x,y)
plt.show()
