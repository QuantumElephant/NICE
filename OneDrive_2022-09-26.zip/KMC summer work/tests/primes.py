# mmkay so I'm going to try some simple prime finder
# let's start with less than 100
# if it's greater than 100 it'll tell you that you're a dumbass
# so basically primes can't be divided by any number other than 1 and themselves
# so my idea was that you can test whether it's divisible by everything from 2 to 1/2 of the number
# we don't want to include 1 because duh
print("Acme Prime Finder for values less than 10000000000")

		#BELOW IS THE USER ENTERING INFO FOR FINDING PRIMES
val = int(input("Enter a value less than 10000000000 to determine if it's prime:"))
if val>1e10:
	print("You jackass," + str(val) + " is more than 10000000000, learn to count")
if val <=0:
	print("You tried to cheat the system huh? Too bad that shit doesn't fly here")
i=2
if val<=1e10 and val>0:
	while i<=round(val/2):
		if val%i != 0:	
			print(str(i) + " is not a factor")
			i+=1
		elif val%i==0:
			print("That's not a prime")
			break
	if i>round(val/2):
		print("congratulations, you found a prime: " + str(val)) 
		

		# NOW WE'RE GOING TO TRY FIGURING OUT WHICH NUMBERS FROM 0-X IS A PRIME
#nums = list(range(1,10))
#prime = []
#noprime = []
#i=2
#for i in nums:
#	while i<=round(nums[i]/2):
#		if nums[i]%i != 0:	
#			i+=1
#		elif nums[i]%i==0:
#			noprime.append(nums[i])
#			i+=1
#	if i>round(nums[i]/2):
#		prime.append(nums[i])
#		i+=1 
#print(prime)


