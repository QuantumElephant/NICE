import numpy as np
import nice
from nice.nekmc import NEKMCSolver
from nice.nekmc import KMCSolver
import matplotlib.pyplot as plt
import csv
import os.path

GIC = 1e4#greatest initial concentration
SIC = 1e-4#smallest initial concentration
 # number of points to plot #k = 0,1,2,3....n=100, therefore 101 numbers
ICP = 400#number of initial cocnentrations for plot #number of points + 1
def Dime(k):
    con = (np.exp(np.log(SIC)+(np.log(GIC/SIC)*k)/(ICP)))
    return con
k=1
initial_concs = np.array([1.0, Dime(k),1.0e-4, 0.0, 0.0, 0.0]) #A, D, R
concs  = np.array([1.0, Dime(k), 1.0e-4, 0.0, 0.0, 0.0]) # A, D, R
keqs   = np.array([1, 100, 1, 100]) #A+D, D+R,A+DR, AD+R
stoich = np.array([[-1, -1,  0,  1,  0,  0], #this represents a rxn - this shows that A + D --> AD
                   [ 0, -1, -1,  0,  1,  0], # D + R -->DR
                   [ 0,  0, -1, -1,  0,  1],
                   [-1,  0,  0,  0, -1,  1]]) #k/1e6 and conc *1e6

with open ("Figure4.txt", "w") as f:
    solver = NEKMCSolver(concs, stoich, keq_values=keqs, phi=1.0)
    MAX = 10000000
    RUN = ICP
    x = []
    i = 0
    while i < RUN:
        x.append(np.log(solver.concs[1])) #log(D)
        solver.run(mode='static', step=1e-8, maxiter=MAX)
        #solver.run(mode='dynamic', step=1e-8, maxiter=MAX, inner=1000)
        ans = str(solver.concs[5]/initial_concs[2])
        #ans = str(solver.run()[0])
        f.write(ans + "\n")
        solver.concs[0] = initial_concs[0]
        solver.concs[2] = initial_concs[2]
        solver.concs[3] = initial_concs[3]
        solver.concs[4] = initial_concs[4]
        solver.concs[5] = initial_concs[5]
        k+=1
        solver.concs[1] = Dime(k)
        
        i+=1


with open ("Figure4.txt",'r') as csvfile:
    y = []
    plots = csv.reader(csvfile, delimiter=' ')
    for row in plots:
        a = (row[0])
        y.append(float(a))
    
    plt.plot(x,y, label='D/ADR')
    plt.xlabel('Log(initial D)')
    plt.ylabel('[ADR]/[R]')
    plt.title('Relationship Between Concentration of ADR/Receptor and Dimerizer'
              +'\n'+ '[A] =' + str(initial_concs[0])+'\n'+ '[R] =' + str(initial_concs[2]))
    plt.show()


