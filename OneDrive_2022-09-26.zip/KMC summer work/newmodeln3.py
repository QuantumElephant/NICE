import numpy as np
import nice
from nice.nekmc import NEKMCSolver
from nice.nekmc import KMCSolver
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import csv
import os.path
from mpl_toolkits import mplot3d

# MAX N=3 MODEL
keqs = np.array([10, 20, 10, 20, 40, 40]) #AB+D, AB+ABD, ABC+D,AB2D+C
stoich = np.array([[-1, -1,  0,  1,  0,  0,  0,  0,  0,  0,  0],
                   [-1,  0,  0, -1,  0,  1,  0,  0,  0,  0,  0],
                   [ 0, -1, -1,  0,  1,  0,  0,  0,  0,  0,  0],
                   [ 0, -1,  0,  0,  0,  0,  1, -1,  0,  0,  0],
		   [-1,  0,  0,  0,  0, -1,  0,  0,  1,  0,  0],
		   [ 0, -1,  0,  0,  0,  0,  0,  0,  0, -1,  1]])
#AB, D, CAB, ABD, CABD, (AB)_2D, C(AB)_2D, C(AB)_2, (AB)_3D, C(AB)_3, C(AB)_3D
#concs = np.array([AB[i], 1.0, ABC[j], 0.0, 0.0, 0.0, 0.0, (0.5**1)*ABC[j], 0.0, (0.5**2)*ABC[j], 0.0])
#ans = ((solver.concs[4] + solver.concs[6] + solver.concs[10])/(ABC[j] + (0.5**1)*ABC[j] + (0.5**2)*ABC[j]))

AB = [] # first went from 0.1 to 102.4
for i in range(51):
	AB.append(0.0001*(1.25**i))

x=[]
y_1=[]
y_2=[]
y_3=[]
y_4=[]

with open('newmodeln3.txt','w') as text:
	for i in range(0,len(AB)):
		concs = np.array([AB[i], 1.0, 0.1, 0.0, 0.0, 0.0, 0.0, (0.5**1)*0.1, 0.0, (0.5**2)*0.1, 0.0])
		solver = NEKMCSolver(concs,stoich,keq_values=keqs,phi=1.0)
		t,s,n = solver.run(mode='dynamic',step=1e-8,maxiter=5e8,inner=100)
		exact = nice.ExactSolver(concs,stoich,keq_values=keqs)
		exact.run(guess=solver.compute_zeta(),tol=1.0e-10)
		ans = ((solver.concs[4] + solver.concs[6] + solver.concs[10])/(0.1 + (0.5**1)*0.1 + (0.5**2)*0.1))
		text.write(str(ans) + '\n')
		x.append(np.log10(AB[i]))
		y_1.append(ans)
		i=+1
	for i in range(0,len(AB)):
		concs = np.array([AB[i], 1.0, 0.2, 0.0, 0.0, 0.0, 0.0, (0.5**1)*0.2, 0.0, (0.5**2)*0.2, 0.0])
		solver = NEKMCSolver(concs,stoich,keq_values=keqs,phi=1.0)
		t,s,n = solver.run(mode='dynamic',step=1e-8,maxiter=5e8,inner=100)
		exact = nice.ExactSolver(concs,stoich,keq_values=keqs)
		exact.run(guess=solver.compute_zeta(),tol=1.0e-10)
		ans = ((solver.concs[4] + solver.concs[6] + solver.concs[10])/(0.2 + (0.5**1)*0.2 + (0.5**2)*0.2))
		text.write(str(ans) + '\n')
		y_2.append(ans)
		i=+1
	for i in range(0,len(AB)):
		concs = np.array([AB[i], 1.0, 0.4, 0.0, 0.0, 0.0, 0.0, (0.5**1)*0.4, 0.0, (0.5**2)*0.4, 0.0])
		solver = NEKMCSolver(concs,stoich,keq_values=keqs,phi=1.0)
		t,s,n = solver.run(mode='dynamic',step=1e-8,maxiter=5e8,inner=100)
		exact = nice.ExactSolver(concs,stoich,keq_values=keqs)
		exact.run(guess=solver.compute_zeta(),tol=1.0e-10)
		ans = ((solver.concs[4] + solver.concs[6] + solver.concs[10])/(0.4 + (0.5**1)*0.4 + (0.5**2)*0.4))
		text.write(str(ans) + '\n')
		y_3.append(ans)
		i=+1
	for i in range(0,len(AB)):
		concs = np.array([AB[i], 1.0, 0.05, 0.0, 0.0, 0.0, 0.0, (0.5**1)*0.05, 0.0, (0.5**2)*0.05, 0.0])
		solver = NEKMCSolver(concs,stoich,keq_values=keqs,phi=1.0)
		t,s,n = solver.run(mode='dynamic',step=1e-8,maxiter=5e8,inner=100)
		exact = nice.ExactSolver(concs,stoich,keq_values=keqs)
		exact.run(guess=solver.compute_zeta(),tol=1.0e-10)
		ans = ((solver.concs[4] + solver.concs[6] + solver.concs[10])/(0.05 + (0.5**1)*0.05 + (0.5**2)*0.05))
		text.write(str(ans) + '\n')
		y_4.append(ans)
		i=+1

plt.plot(x,y_1,label='[ABC]=0.1')
plt.plot(x,y_2,label='[ABC]=0.2')
plt.plot(x,y_3,label='[ABC]=0.4')
plt.plot(x,y_4,label='[ABC]=0.05')
plt.xlabel('log_10([AB])')
plt.ylabel('Ratio of Product/Reactant')
plt.title('Relationship Between [AB] and the Ratio' + '\n' + 'of Product/Reactants when n_max=3')
plt.legend()
plt.savefig('AB vs PR n3')