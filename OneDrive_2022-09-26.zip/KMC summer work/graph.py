import matplotlib.pyplot as plt
x=[-2,0,1,2,3, 3.25, 3.5, 3.75 ,4,5,6,7,8]
y=[0.9969920000078317, 0.9969970000078319, 0.9970240000078326, 0.9969980000078319, 0.9976500000078506, 0.9922240000076946 , 0.9542090000066015 , 0.7942490000020017, 0.4737639999942424, 0.020305999999999654, 0.001761999999999951, 0.00017199999999999963, 1.6380000000000084e-05]
plt.plot(x,y)
plt.xlabel('log_10([AB])')
plt.ylabel('Concentration of Dead Cells in nM')
plt.title('How the Concentration of Dead Cells Vary' +'\n' + 'With the Initial Concentration of AB' + '\n' + 'n = 10, m = 5')
plt.savefig('AB vs Death')