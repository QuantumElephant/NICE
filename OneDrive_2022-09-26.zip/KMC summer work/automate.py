import numpy as np
import nice
from nice.nekmc import NEKMCSolver
from nice.nekmc import KMCSolver
import matplotlib.pyplot as plt
import csv
import os.path

n=5
p=2
q=0.5
K=10
K1=10
keqs = [0 for i in range(3*n+n**2)]
concs = [0 for i in range(4*n+3)]
concs[n+1] = 1.0 # D
stoich = np.zeros(shape=(len(keqs),len(concs)),dtype='int')
keqs[0] = K
keqs[n] = K1
stoich[0,0] = -1 #AB 
stoich[0,n+1] = -1 #D
stoich[0,1] = 1 #ABD
"""
the first rxn, AB + D -> ABD
"""

stoich[n,n+2] = -1 # CAB
stoich[n,n+1] = -1 # D
stoich[n,2*n+2] = 1 # CABD
"""
the nth rxn, CAB + D -> CABD
"""

stoich[2*n+n**2,4*n+2] = -1 # C
stoich[2*n+n**2,0] = -1 # AB
stoich[2*n+n**2,n+2] = 1 #CAB
"""
C + AB -> CAB
"""


#AB, ABD, AB2D,..., ABnD, D, CAB, CAB2,..., CABn, CABD, CAB2D,..., CABnD, ..., CAB(2n)D, C

for i in range(1,n):
	stoich[i,0] = -1 # AB 
	stoich[i,i] = -1 # ABn-1D
	stoich[i,i+1] = 1 #ABnD
	#the first n rxns, AB + ABn-1D -> ABnD
for i in range(n+1,2*n):
	stoich[i,n+1] = -1 # D
	stoich[i,2+i] = -1 # CABn
	stoich[i,i+n+2] = 1 # CABnD
	#the second n rxns, CABn + D -> CABnD
for i in range(0,n):
	stoich[2*n+i*n,n+2+i] = -1
	for j in range(1,n):
		stoich[2*n+i*n+j,n+2+i]=-1
	#CABn	
	stoich[2*n+i,i+1] = -1 
	for j in range(1,n):
		stoich[2*n+i+j*n,i+1] = -1
	# ABnD
	stoich[2*n+i,2*n+3+i] = 1 # CABD->CABn+1D
	for j in range(1,n):
		stoich[(2+j)*n+i,2*n+3+i+j] = 1
	#ABn+mD
	#ABnD + CABm -> CABn+mD
for i in range(1,n):
	stoich[2*n+n**2+i,n+1+i] = -1 #CABn-1
	stoich[2*n+n**2+i,0]=-1 # AB 
	stoich[2*n+n**2+i,n+2+i] = 1 #CABn
	# AB + CABn-1 -> CABn
for i in range(1,n):
	keqs[i] = p**i*K
for i in range(n+1,2*n):
	keqs[i] = p**(i-n)*K

AB=[0.0001]
#for i in range(10):
#	AB.append(0.0001*(2**i))
x=[]
y=[]
for i in range(0,len(AB)):
	concs[0] = AB[i]
	concs[n+2] = 0.05 # CAB
	for i in range(n+3,2*n+2):
		concs[i] = q**(i-(n+2))*concs[n+2]
	#solver = nice.NEKMCSolver(concs,stoich,keq_values = keqs)
	#solver.iterate(step=1e-8,niter=5e8)	
	#solver.run_simulation(mode='dynamic', step = 1e-8,niter=5e8)
	#exact = nice.ExactSolver(concs,stoich,keq_values=keqs)
	#exact.optimize(guess=solver.compute_zeta(),tol=1e-10)
	#reac=concs[n+2]
	#for i in range(n+3,2*n+2):
	#	reac+=concs[i]
	#prod=solver.concs[2*n+2]
	#for i in range(2*n+3, 3*n+2):
	#	prod+=solver.concs[i]
	#ans = prod/reac
	#y.append(ans)
	#x.append(np.log10(AB[i]))

#plt.plot(x,y,label='[ABC]=0.05')
#plt.xlabel('log_10([AB])')
#plt.ylabel('Ratio of Product/Reactant')
#plt.title('Relationship Between [AB] and the Ratio' + '\n' + 'of Product/Reactants when n_max=2')
#plt.legend()
#plt.savefig('AB vs PR n2')

print(str(keqs) + '\n' + str(stoich) + '\n' +  str(concs))
#print(prod)
#print(reac)
#print(ans)

#AB + D -> ABD
#AB + ABD -> (AB)2D
#AB + (AB)2D -> (AB)3D
#AB + (AB)3D -> (AB)4D
#AB + (AB)4D -> (AB)5D
#AB + (AB)5D -> (AB)6D
#AB + (AB)6D -> (AB)7D

#CAB + D -> CABD
#C(AB)2 + D -> C(AB)2D
#C(AB)3 + D -> C(AB)3D
#C(AB)4 + D -> C(AB)4D
#C(AB)5 + D -> C(AB)5D
#C(AB)6 + D -> C(AB)6D
#C(AB)7 + D -> C(AB)7D DON'T NEED THESE REACTIONS

#ABD + CAB -> CAB2D
#ABD + CAB2D -> CAB3D
#...
#ABD+CABnD -> CABn+1D
#AB2D+CAB -> CAB3D
#...
#AB2D + CABnD -> CABn+2D
#...
#ABnD + CABnD -> CAB2nD

#C + AB -> CAB
#CAB + AB -> CAB2
#...
#CABn-1+AB -> CABn
#AB, ABD, AB2D,..., ABnD, D, CAB, CAB2,..., CABn, CABD, CAB2D,..., CABnD, ..., CAB(2n)D, C
# reactants = CABn = n+2 ->2n+1 **technically it'd be 2n+2 for the coding b/c it doesn't take the last one
# products = CABnD = 2n+2 -> 3n+1 **technically it'd be 3n+2 for the coding b/c it doesn't take the last one

