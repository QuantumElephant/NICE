import numpy as np
import nice
from nice.nekmc import NEKMCSolver
from nice.nekmc import KMCSolver
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import csv
import os.path
from mpl_toolkits import mplot3d

# MAX N=5 MODEL
#AB, D, CAB, ABD, CABD, (AB)_2D, C(AB)_2D, C(AB)_2, (AB)_3D, C(AB)_3, C(AB)_3D, (AB)_4D, C(AB)_4, C(AB)_4D, (AB)_5D, C(AB)_5,C(AB)_5D

keqs = np.array([10, 20, 10, 20, 40, 40, 80, 80, 160, 160])
stoich = np.array([
[-1,-1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
[-1, 0, 0,-1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
[ 0,-1,-1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
[ 0,-1, 0, 0, 0, 0, 1,-1, 0, 0, 0, 0, 0, 0, 0, 0, 0],
[-1, 0, 0, 0, 0,-1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0],
[ 0,-1, 0, 0, 0, 0, 0, 0, 0,-1, 1, 0, 0, 0, 0, 0, 0],
[-1, 0, 0, 0, 0, 0, 0, 0,-1, 0, 0, 1, 0, 0, 0, 0, 0],
[ 0,-1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,-1, 1, 0, 0, 0],
[-1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,-1, 0, 0, 1, 0, 0],
[ 0,-1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,-1, 1]])


AB = [] # first went from 0.1 to 102.4
for i in range(51):
	AB.append(0.0001*(1.25**i))

x=[]
y_1=[]
y_2=[]
y_3=[]
y_4=[]

with open("n5.txt","w") as text:
	for i in range(0,len(AB)):
		concs = np.array([AB[i], 1.0, 0.05, 0.0, 0.0, 0.0, 0.0, (0.5**1)*0.05, 0.0, (0.5**2)*0.05, 0.0, 0.0, (0.5**3)*0.05, 0.0, 0.0, (0.5**4)*0.05, 0.0])
		solver = NEKMCSolver(concs,stoich,keq_values=keqs,phi=1.0)
		t,s,n = solver.run(mode='dynamic',step=1e-8,maxiter=5e8,inner=1000)
		exact = nice.ExactSolver(concs,stoich,keq_values=keqs)
		exact.run(guess=solver.compute_zeta(),tol=1.0e-10)
		ans = (solver.concs[4] + solver.concs[6] + solver.concs[10] + solver.concs[13] + solver.concs[16])/(concs[2] + concs[7] + concs[9] + concs[12] + concs[15])
		text.write(str(ans) + ' | ' + '[AB] = ' + str(AB[i]) + '\n')
		y_1.append(ans)
	for i in range(0,len(AB)):
		concs = np.array([AB[i], 1.0, 0.1, 0.0, 0.0, 0.0, 0.0, (0.5**1)*0.1, 0.0, (0.5**2)*0.1, 0.0, 0.0, (0.5**3)*0.1, 0.0, 0.0, (0.5**4)*0.1, 0.0])
		solver = NEKMCSolver(concs,stoich,keq_values=keqs,phi=1.0)
		t,s,n = solver.run(mode='dynamic',step=1e-8,maxiter=5e8,inner=1000)
		exact = nice.ExactSolver(concs,stoich,keq_values=keqs)
		exact.run(guess=solver.compute_zeta(),tol=1.0e-10)
		ans = (solver.concs[4] + solver.concs[6] + solver.concs[10] + solver.concs[13] + solver.concs[16])/(concs[2] + concs[7] + concs[9] + concs[12] + concs[15])
		text.write(str(ans) + ' | ' + '[AB] = ' + str(AB[i]) + '\n')
		x.append(np.log10(AB[i]))
		y_2.append(ans)
		i=+1
	for i in range(0,len(AB)):
		concs = np.array([AB[i], 1.0, 0.2, 0.0, 0.0, 0.0, 0.0, (0.5**1)*0.2, 0.0, (0.5**2)*0.2, 0.0, 0.0, (0.5**3)*0.2, 0.0, 0.0, (0.5**4)*0.2, 0.0])
		solver = NEKMCSolver(concs,stoich,keq_values=keqs,phi=1.0)
		t,s,n = solver.run(mode='dynamic',step=1e-8,maxiter=5e8,inner=1000)
		exact = nice.ExactSolver(concs,stoich,keq_values=keqs)
		exact.run(guess=solver.compute_zeta(),tol=1.0e-10)
		ans = (solver.concs[4] + solver.concs[6] + solver.concs[10] + solver.concs[13] + solver.concs[16])/(concs[2] + concs[7] + concs[9] + concs[12] + concs[15])
		text.write(str(ans) + ' | ' + '[AB] = ' + str(AB[i]) + '\n')
		y_3.append(ans)
		i=+1
	for i in range(0,len(AB)):
		concs = np.array([AB[i], 1.0, 0.4, 0.0, 0.0, 0.0, 0.0, (0.5**1)*0.4, 0.0, (0.5**2)*0.4, 0.0, 0.0, (0.5**3)*0.4, 0.0, 0.0, (0.5**4)*0.4, 0.0])
		solver = NEKMCSolver(concs,stoich,keq_values=keqs,phi=1.0)
		t,s,n = solver.run(mode='dynamic',step=1e-8,maxiter=5e8,inner=1000)
		exact = nice.ExactSolver(concs,stoich,keq_values=keqs)
		exact.run(guess=solver.compute_zeta(),tol=1.0e-10)
		ans = (solver.concs[4] + solver.concs[6] + solver.concs[10] + solver.concs[13] + solver.concs[16])/(concs[2] + concs[7] + concs[9] + concs[12] + concs[15])
		text.write(str(ans) + ' | ' + '[AB] = ' + str(AB[i]) + '\n')		
		y_4.append(ans)
		i=+1

# 2D PLOT
plt.plot(x,y_1,label='[ABC]=0.05')
plt.plot(x,y_2,label='[ABC]=0.1')
plt.plot(x,y_3,label='[ABC]=0.2')
plt.plot(x,y_4,label='[ABC]=0.4')
plt.xlabel('log_10([AB])')
plt.ylabel('Ratio of Product/Reactant')
plt.title('Relationship Between [AB] and the Ratio' + '\n' + 'of Product/Reactants when n_max=5')
plt.legend()
plt.savefig('AB vs PR n5')


#AB + D -> ABD K = 10 - 0, 1, 3
#AB + ABD -> (AB)2D K = p^nK = 20 - 0, 3, 5
#CAB + D -> CABD K = 10 - 1, 2, 4
#C(AB)2 + D -> C(AB)2D K= p^(n-1)K = 20 - 7, 1, 6
#AB + (AB)2D -> (AB)3D K = 40 - 0, 5, 8
#C(AB)3 + D -> C(AB)3D K = 40 - 9, 1, 10
#AB + (AB)3D -> (AB)4D K = 80 - 0, 8, 11
#C(AB)4 + D -> C(AB)4D K = 80 - 12, 1, 13
#AB +(AB)4D -> (AB)5D K = 160 - 0, 11, 14
#C(AB)5 + D -> C(AB)5D K = 160 - 15, 1, 16

#ans = (CABD + C(AB)2D + C(AB)3D + C(AB)4D + C(AB)5D) / (CAB + C(AB)2 + C(AB)3 + C(AB)4 + C(AB)5)
#ans = (solver.concs[4] + solver.concs[6] + solver.concs[10] + solver.concs[13] + solver.concs[16])/(concs[2] + concs[7] + concs[9] + concs[12] + concs[15])