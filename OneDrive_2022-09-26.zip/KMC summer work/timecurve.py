import nice
import numpy as np
from nice.nekmc import NEKMCSolver
from nice.nekmc import KMCSolver
import matplotlib.pyplot as plt
import matplotlib.pyplot as plt
import csv
import os.path

x=[]
y=[]
t1=[]
concs = np.array([1.0,10,0.0001,0.0,0.0,0.0]) #A,D,R,AD,DR,ADR try D=10 to correspond with the 2nd peak
keqs = np.array([1.0,100,1.0,100]) # A+D, D+R, A+DR, AD+R
stoich = np.array([[-1,-1, 0, 1, 0, 0],
		   [ 0,-1,-1, 0, 1, 0],
		   [ 0, 0,-1,-1, 0, 1],
		   [-1, 0, 0, 0,-1, 1]])
with open('time1.txt', 'w') as f:
	for i in np.arange(0,1e6,100):
		nekmc = nice.NEKMCSolver(concs,stoich,keq_values=keqs)
		t,s,n=nekmc.run(mode='dynamic',step=1e-8,maxiter=5e8,inner=100)
		exact=nice.ExactSolver(concs,stoich,keq_values=keqs)
		exact.run(guess=nekmc.compute_zeta(),tol=1.0e-10)
		y.append(exact.concs[5])
		t1.append(t)
		f.write(str(t) + ' | ' + str(exact.concs[5]) + '\n')
		#i+=1
#with open('time.txt', 'r') as csvfile:
#	time = csv.reader(csvfile,delimiter=' ')
#	for row in time:
#		a=row[0]
#		x.append(float(a))
t2=np.cumsum(t1)
#y1=np.cumsum(y)
plt.plot(t2,y,'ro')
plt.xlabel('Reaction Time')
plt.ylabel('[ADR]')
plt.title('Time Curve for the Formation of ADR')
plt.show()
		
